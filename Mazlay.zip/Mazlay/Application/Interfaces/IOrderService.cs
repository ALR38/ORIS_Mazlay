﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Application.Interfaces;

public interface IOrderService
{
    Task<int> CreateAsync(int userId, IReadOnlyList<CartLineDto> lines);
}