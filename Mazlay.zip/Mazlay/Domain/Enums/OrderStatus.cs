﻿namespace Domain.Enums;

public enum OrderStatus { Draft, Paid, Shipped, Done, Cancelled }