﻿namespace Infrastructure.Identity;

public class IdentitySeeder
{
    
}